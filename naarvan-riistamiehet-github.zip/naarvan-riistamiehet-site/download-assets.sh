#!/usr/bin/env bash
# Lataa vanhalta nettisivut.fi/Yhdistysavain-sivulta kuvat ja dokumentit
# tämän uuden sivuston assets-kansioon. Aja tämä kerran ennen ensimmäistä
# committia, omalla koneellasi (tämä ei toiminut pilviympäristöstä, koska
# sillä ei ole pääsyä mielivaltaisiin verkko-osoitteisiin).
#
# Käyttö:
#   chmod +x download-assets.sh
#   ./download-assets.sh

set -e
cd "$(dirname "$0")"

mkdir -p assets/images assets/docs

echo "Ladataan kuvia..."
curl -sL -o assets/images/hero-metso.jpg "https://bin.yhdistysavain.fi/1612011/Mun05iGV82HtreJ2lfu00akTNk/Metso%20NRM.jpg"
curl -sL -o assets/images/galleria-1.jpg "https://bin.yhdistysavain.fi/1612011/qy9Ba0200maty9Bkmy1W0chS2J/2e176cc2-001c-414b-a49d-0dca547d9183.jpg"
curl -sL -o assets/images/galleria-2.jpg "https://bin.yhdistysavain.fi/1612011/F2yQnwGTjdBTustSezha0chS2K/a02e7ac3-ba26-43da-82a8-33ed3d442fae.jpg"
curl -sL -o assets/images/galleria-3.jpg "https://bin.yhdistysavain.fi/1612011/jEUWP9fMzorscTcK99FR0chS2L/af9601df-7acd-4579-abe7-56d6bc120c98.jpg"
curl -sL -o assets/images/galleria-4.jpg "https://bin.yhdistysavain.fi/1612011/fD7WHquI3Ntvom98XZca0chS2L/b20b04e3-46f7-4584-abd5-7b0c4a18421c.jpg"
curl -sL -o assets/images/galleria-5.jpg "https://bin.yhdistysavain.fi/1612011/bnLMfdLG8h4B5yZydKqr0chS2M/dc5541e6-5840-4384-9411-db0ed3f30fb4.jpg"
curl -sL -o assets/images/galleria-6.jpg "https://bin.yhdistysavain.fi/1612011/xEO6EjotGuNleghp5aW40chS2N/de9900cd-d5d5-42ff-9200-aba59c091825.jpg"

echo "Ladataan dokumentteja..."
curl -sL -o assets/docs/saannot.pdf "https://bin.yhdistysavain.fi/1612011/1PeVevyIU8lBFCyvIlt20akTHz/SaannotNRMry.pdf"
curl -sL -o assets/docs/hirven-metsastyssaannot.pdf "https://bin.yhdistysavain.fi/1612011/3w2S6bUkSSLnnYBiYish0akTJv/Hirvenmetsstyssnnt.pdf"
curl -sL -o assets/docs/karhun-metsastyssaannot.odt "https://bin.yhdistysavain.fi/1612011/BVhr9vpKOCYOSpdQMfEE0akTKZ/Karhun_metsstys_2015_Naarvan_riistamiehet_ry.odt"

echo "Valmis. Kuvat kansiossa assets/images/, dokumentit kansiossa assets/docs/."
